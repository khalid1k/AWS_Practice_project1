const response = require("../../utills/response");
// const {createUser} = require("../../utills/dyanmoDb");
const { putItem, getItem} = require("../../utills/dyanmoDb");
// module.exports.createUser = async (event, context) => {
    
//     console.log("event ", event.body);
//     const body = JSON.parse(event.body);
//     console.log("now body value is ", body);
//     //create and save the user to the database
//     const res = await createUser(body, "usersTable-dev")
//     console.log("response is ", response);
//     return {...response.success, body: JSON.stringify(res)}
// }


// const AWS = require("aws-sdk");

exports.createUser = async (event) => {
    try {
        const body = JSON.parse(event.body);
        
        // Extracting fields from request body
        const { id, name, email, age } = body;

        const params = {
            TableName: "usersTable-dev",
            Item: { id, name, email, age }
        };

       const res = await putItem(TableName, params.Item);
       console.log("respone of creating user is ", res);

        return {
            statusCode: 200,
            body: JSON.stringify({ message: "User created successfully", user: params.Item })
        };
        // return {...response.success, body: JSON.stringify(res)}
    } catch (error) {
        console.error("Error inserting user:", error);
        // 
        // return response.error;
    }
};
